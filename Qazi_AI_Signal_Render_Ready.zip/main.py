from flask import Flask, render_template, request
import random

app = Flask(__name__)

@app.route('/', methods=['GET', 'POST'])
def index():
    result = ''
    urdu_result = ''
    if request.method == 'POST':
        url = request.form['chart_link']
        timeframe = request.form['timeframe']
        direction = random.choice(['UP', 'DOWN'])
        result = f"Market will go {direction} in {timeframe}"
        urdu_result = "مارکیٹ اوپر جائے گی" if direction == "UP" else "مارکیٹ نیچے جائے گی"
    return render_template("index.html", result=result, urdu_result=urdu_result)

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0')
